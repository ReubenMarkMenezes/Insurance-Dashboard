
# Insurance Policy Status Intelligence (Streamlit)

A Streamlit Cloud-ready dashboard for:
- **10 actionable charts** with Occupation-based multi-select filtering
- **Model Lab**: Train & evaluate **Decision Tree, Random Forest, Gradient Boosted Tree** (DT/RF/GBRT)
- **Batch Predict**: Upload a new CSV and download predictions for `POLICY_STATUS`

## How to use

1. **Add your data**
   - Commit your dataset as `Insurance.csv` in the repo **or**
   - Upload it from the sidebar in the running app.

2. **Run on Streamlit Cloud**
   - Push this repo to GitHub.
   - Create a Streamlit Cloud app with `app.py` as the entry point.

3. **Insights Tab**
   - Ten charts render automatically.
   - Use the sidebar **Occupation filter** (auto-detected column like `OCCUPATION`) to slice everywhere.

4. **Model Lab**
   - Click **Run DT / RF / GBRT** to train all three.
   - See confusion matrices for train/test, metrics table, and a unified ROC.
   - Light 5-fold CV on a tiny stratified set to keep Streamlit Cloud speedy.

5. **Batch Predict**
   - Choose a trained model (or click **Train a quick RF now**).
   - Upload a new CSV, and **download** scored predictions.

## Requirements
We avoid versions to reduce dependency issues on Streamlit Cloud:
```
streamlit
pandas
numpy
scikit-learn
plotly
```

> If you see missing optional columns (e.g., OCCUPATION), the app will gracefully skip those specific charts/filters.

## Notes
- No folders are created per your instruction. All files sit in the repo root.
- If `POLICY_STATUS` is multiclass, ROC uses macro-averaged One-vs-Rest.
