
# (Reserved for future extension. Keeping flat file structure as requested.)
# To keep the repository simple, all functionality is embedded in app.py per user's "no folders" constraint.
