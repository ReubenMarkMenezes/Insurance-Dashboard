
import streamlit as st
import pandas as pd
import numpy as np
from io import BytesIO
from typing import Dict, Tuple, List

from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, label_binarize
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    confusion_matrix, accuracy_score, precision_recall_fscore_support,
    roc_auc_score, roc_curve, auc, classification_report
)
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

import plotly.express as px
import plotly.graph_objects as go

# ------------------------------
# App Config
# ------------------------------
st.set_page_config(page_title="Insurance Policy Status Intelligence", layout="wide")

st.title("📊 Insurance Policy Status Intelligence (Streamlit)")
st.caption("End-to-end dashboard: insights, modeling (DT/RF/GBRT), and batch prediction")

# ------------------------------
# Helpers
# ------------------------------
@st.cache_data
def load_data(default_path: str = "Insurance.csv") -> pd.DataFrame:
    try:
        df = pd.read_csv(default_path)
        return df
    except Exception:
        return pd.DataFrame()

def find_col(df: pd.DataFrame, candidates: List[str]) -> str:
    cols = {c.lower(): c for c in df.columns}
    for cand in candidates:
        if cand.lower() in cols:
            return cols[cand.lower()]
    return ""

def get_feature_splits(df: pd.DataFrame, target_col: str) -> Tuple[List[str], List[str]]:
    numeric_cols = df.drop(columns=[target_col]).select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = [c for c in df.columns if c not in numeric_cols + [target_col]]
    return numeric_cols, categorical_cols

def build_preprocess(numeric_cols: List[str], categorical_cols: List[str]) -> ColumnTransformer:
    num_tf = Pipeline(steps=[("imputer", SimpleImputer(strategy="mean"))])
    cat_tf = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse=False))
    ])
    return ColumnTransformer([("num", num_tf, numeric_cols), ("cat", cat_tf, categorical_cols)])

def aggregate_importances(feature_names: List[str], importances: np.ndarray, numeric_cols: List[str]) -> pd.Series:
    agg = {}
    for fname, imp in zip(feature_names, importances):
        if "=" in fname:
            base = fname.split("=", 1)[0]
        else:
            base = fname if fname in numeric_cols else fname.split("_", 1)[0]
        agg[base] = agg.get(base, 0.0) + float(imp)
    s = pd.Series(agg).sort_values(ascending=False)
    return s

def get_ohe_feature_names(preprocess: ColumnTransformer, numeric_cols: List[str], categorical_cols: List[str]) -> List[str]:
    names: List[str] = []
    if "num" in preprocess.named_transformers_:
        names.extend(numeric_cols)
    if "cat" in preprocess.named_transformers_:
        ohe = preprocess.named_transformers_["cat"].named_steps["onehot"]
        names.extend(ohe.get_feature_names_out(categorical_cols).tolist())
    return names

def ensure_session_models():
    if "trained_models" not in st.session_state:
        st.session_state.trained_models = {}  # name -> fitted pipeline
    if "class_labels" not in st.session_state:
        st.session_state.class_labels = None
    if "target_col" not in st.session_state:
        st.session_state.target_col = None

# ------------------------------
# Data Ingestion
# ------------------------------
st.sidebar.header("📥 Data")
uploaded = st.sidebar.file_uploader("Upload Insurance dataset (CSV). If omitted, the app tries to read 'Insurance.csv' from the repo.", type=["csv"])
if uploaded:
    df = pd.read_csv(uploaded)
else:
    df = load_data()

if df.empty:
    st.warning("No data loaded. Please upload a CSV or add 'Insurance.csv' to the repo.")
    st.stop()

# Guess key columns
target_col = find_col(df, ["POLICY_STATUS", "policy_status", "Policy_Status", "Status"])
occ_col = find_col(df, ["OCCUPATION", "occupation", "job", "profession", "Employment", "employment_type"])

if not target_col:
    st.error("Target column 'POLICY_STATUS' (or variant) not found. Please ensure your CSV has it.")
    st.stop()

st.success(f"Dataset loaded with **{len(df)} rows** and **{df.shape[1]} columns**. Target = `{target_col}`")

# Occupation filter
if occ_col:
    occ_options = sorted(df[occ_col].dropna().astype(str).unique().tolist())
    sel_occs = st.sidebar.multiselect("Filter by Occupation (applies everywhere)", occ_options, default=occ_options[:min(5, len(occ_options))])
    if sel_occs:
        df = df[df[occ_col].astype(str).isin(sel_occs)]
else:
    st.sidebar.info("Occupation column not detected; charts will show full dataset.")

# ------------------------------
# Tabs
# ------------------------------
tab1, tab2, tab3, tab4 = st.tabs(["📈 Insights (10 Charts)", "📚 Data Preview", "🤖 Model Lab (DT / RF / GBRT)", "📦 Batch Predict & Download"])

# ------------------------------
# Tab 1: Insights (10 Charts)
# ------------------------------
with tab1:
    st.subheader("Actionable Insights")

    # Prepare safe lists
    policy_col = target_col
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = [c for c in df.columns if c not in numeric_cols]

    # Helper: safe pick numeric cols
    def pick_numeric(n=2):
        cols = numeric_cols[:n] if len(numeric_cols) >= n else numeric_cols
        return cols

    charts = []

    # 1) Policy Status distribution
    vc = df[policy_col].value_counts().reset_index(names=[policy_col, "count"])
    fig1 = px.bar(vc, x=policy_col, y="count", title="1) Policy Status Distribution")
    charts.append(fig1)

    # 2) Occupation x Policy Status stacked (if occ available)
    if occ_col:
        crosstab = pd.crosstab(df[occ_col].astype(str), df[policy_col].astype(str), normalize="index")*100
        fig2 = px.bar(crosstab.reset_index(), x=occ_col, y=crosstab.columns, title="2) Policy Status Share by Occupation (%)", barmode="stack")
        charts.append(fig2)

    # 3) Numeric histogram by Policy Status (pick first numeric)
    if len(numeric_cols) >= 1:
        n1 = numeric_cols[0]
        fig3 = px.histogram(df, x=n1, color=policy_col, nbins=30, marginal="box", title=f"3) {n1} Distribution by Policy Status")
        charts.append(fig3)

    # 4) Scatter between 2 numeric cols with color by status
    if len(numeric_cols) >= 2:
        n1, n2 = numeric_cols[:2]
        fig4 = px.scatter(df, x=n1, y=n2, color=policy_col, trendline="ols", title=f"4) {n1} vs {n2} with Trendline by Policy Status")
        charts.append(fig4)

    # 5) Correlation heatmap for numeric cols
    if len(numeric_cols) >= 2:
        corr = df[numeric_cols].corr(numeric_only=True)
        fig5 = px.imshow(corr, text_auto=True, aspect="auto", title="5) Correlation Heatmap (Numeric Features)")
        charts.append(fig5)

    # 6) Top-KPIs by occupation (conversion-like metric: share of a chosen 'positive' class if present)
    positive_like = None
    # Heuristic: if a binary class, pick the lexicographically "positive-like" (e.g., Active/Approved)
    classes = df[policy_col].astype(str).unique().tolist()
    if len(classes) == 2:
        positive_like = sorted(classes)[-1]
    # Aggregate rate by occupation
    if occ_col and positive_like:
        grp = (df.groupby(occ_col)[policy_col]
               .apply(lambda s: (s.astype(str) == positive_like).mean())
               .reset_index(name=f"rate_{positive_like}"))
        fig6 = px.bar(grp.sort_values(by=f"rate_{positive_like}", ascending=False).head(15),
                      x=occ_col, y=f"rate_{positive_like}",
                      title=f"6) {positive_like} Rate by Occupation (Top 15)")
        charts.append(fig6)

    # 7) Numeric box plot by policy status (first numeric)
    if len(numeric_cols) >= 1:
        n1 = numeric_cols[0]
        fig7 = px.box(df, x=policy_col, y=n1, points="all", title=f"7) {n1} Spread by Policy Status")
        charts.append(fig7)

    # 8) Feature importance via quick RF (on filtered data)
    try:
        from sklearn.ensemble import RandomForestClassifier
        # Guard: minimal processing for visualization only
        X = df.drop(columns=[policy_col])
        y = df[policy_col].astype(str)
        num_cols, cat_cols_mod = get_feature_splits(df, policy_col)
        pre = build_preprocess(num_cols, cat_cols_mod)
        rf = RandomForestClassifier(n_estimators=150, random_state=42)
        pipe = Pipeline([("pre", pre), ("rf", rf)])
        pipe.fit(X, y)
        feat_names = get_ohe_feature_names(pipe.named_steps["pre"], num_cols, cat_cols_mod)
        importances = pipe.named_steps["rf"].feature_importances_
        agg = {}
        for fname, imp in zip(feat_names, importances):
            base = fname.split("=",1)[0] if "=" in fname else fname if fname in num_cols else fname.split("_",1)[0]
            agg[base] = agg.get(base, 0.0) + float(imp)
        imp_series = pd.Series(agg).sort_values(ascending=False).head(20).reset_index()
        imp_series.columns = ["Feature", "Importance"]
        fig8 = px.bar(imp_series.sort_values("Importance"), x="Importance", y="Feature",
                      orientation="h", title="8) Quick Feature Importance (Random Forest)")
        charts.append(fig8)
    except Exception as e:
        st.info(f"Feature importance skipped due to: {e}")

    # 9) Lift chart (simple deciles) using same RF probabilities (binary only)
    if len(classes) == 2:
        try:
            proba = pipe.predict_proba(X)[:, 1]
            df_lift = pd.DataFrame({"y": (y.astype(str) == positive_like).astype(int), "p": proba})
            df_lift["decile"] = pd.qcut(df_lift["p"], 10, labels=False, duplicates="drop")
            lift = df_lift.groupby("decile").agg(
                responses=("y","sum"),
                total=("y","count"),
                avg_p=("p","mean")
            ).reset_index().sort_values("decile", ascending=False)
            lift["response_rate"] = lift["responses"]/lift["total"]
            fig9 = px.bar(lift, x="decile", y="response_rate", title="9) Lift by Score Decile (higher is better)")
            charts.append(fig9)
        except Exception:
            pass

    # 10) Cohort-like heatmap: policy status by two categorical axes (occupation vs another cat if exists)
    other_cat = ""
    for c in cat_cols:
        if c != occ_col and c != policy_col and df[c].nunique() <= 20:
            other_cat = c; break
    if occ_col and other_cat:
        ct = pd.crosstab(df[occ_col].astype(str), df[other_cat].astype(str), normalize="index")*100
        fig10 = px.imshow(ct, aspect="auto", title=f"10) Share by Occupation vs {other_cat} (%)")
        charts.append(fig10)

    # Render charts in a grid
    for i, fig in enumerate(charts, start=1):
        st.plotly_chart(fig, use_container_width=True)

# ------------------------------
# Tab 2: Data Preview
# ------------------------------
with tab2:
    st.subheader("Dataset Preview")
    st.dataframe(df.head(100), use_container_width=True)
    st.caption("Showing first 100 rows. Apply Occupation filter from the sidebar.")

# ------------------------------
# Tab 3: Model Lab (DT / RF / GBRT)
# ------------------------------
with tab3:
    st.subheader("Train & Evaluate Models")
    st.write("Click the button to run all three models with 5-fold stratified CV (light) and show full test metrics.")

    ensure_session_models()

    run_btn = st.button("🚀 Run DT / RF / GBRT")
    if run_btn:
        # Split
        sss = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
        X = df.drop(columns=[target_col])
        y = df[target_col].astype(str)
        train_idx, test_idx = next(sss.split(X, y))
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
        class_labels = np.unique(y_train)
        st.session_state.class_labels = class_labels.tolist()
        st.session_state.target_col = target_col

        # Preprocess
        num_cols, cat_cols_mod = get_feature_splits(df, target_col)
        preprocess = build_preprocess(num_cols, cat_cols_mod)

        models: Dict[str, object] = {
            "Decision Tree": DecisionTreeClassifier(random_state=42),
            "Random Forest": RandomForestClassifier(n_estimators=200, random_state=42),
            "Gradient Boosted Tree": GradientBoostingClassifier(random_state=42)
        }

        results = []
        roc_fig = go.Figure()
        for name, est in models.items():
            pipe = Pipeline([("preprocess", preprocess), ("model", est)])

            # Light 5-fold CV (on a tiny stratified subset to keep runtime OK on Streamlit Cloud)
            # Sample up to 20 per class
            tiny = []
            tmp = X_train.copy()
            tmp[target_col] = y_train.values
            for cls, g in tmp.groupby(target_col):
                tiny.append(g.sample(n=min(20, len(g)), random_state=42))
            tiny = pd.concat(tiny).sample(frac=1, random_state=42)
            X_cv = tiny.drop(columns=[target_col]); y_cv = tiny[target_col]

            skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
            cv_scores = []
            for tr, va in skf.split(X_cv, y_cv):
                pipe.fit(X_cv.iloc[tr], y_cv.iloc[tr])
                cv_scores.append(pipe.score(X_cv.iloc[va], y_cv.iloc[va]))
            cv_acc = float(np.mean(cv_scores)) if len(cv_scores) else np.nan

            # Fit full train and evaluate
            pipe.fit(X_train, y_train)
            y_pred_tr = pipe.predict(X_train)
            y_pred_te = pipe.predict(X_test)

            tr_acc = accuracy_score(y_train, y_pred_tr)
            te_acc = accuracy_score(y_test, y_pred_te)
            precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred_te, average="weighted", zero_division=0)

            # AUC + ROC
            auc_value = np.nan
            try:
                proba = pipe.predict_proba(X_test)
                if len(class_labels) == 2:
                    mapping = {label:i for i,label in enumerate(class_labels)}
                    auc_value = roc_auc_score(y_test.map(mapping), proba[:,1])
                    fpr, tpr, _ = roc_curve(y_test.map(mapping), proba[:,1])
                    roc_fig.add_trace(go.Scatter(x=fpr, y=tpr, mode="lines", name=f"{name} (AUC={auc(fpr,tpr):.3f})"))
                else:
                    yb = label_binarize(y_test, classes=class_labels)
                    auc_value = roc_auc_score(yb, proba, multi_class="ovr", average="macro")
                    # Macro ROC
                    all_fpr = np.linspace(0,1,200)
                    mean_tpr = np.zeros_like(all_fpr)
                    for i in range(len(class_labels)):
                        fpr_i, tpr_i, _ = roc_curve(yb[:, i], proba[:, i])
                        mean_tpr += np.interp(all_fpr, fpr_i, tpr_i, left=0, right=1)
                    mean_tpr /= len(class_labels)
                    roc_fig.add_trace(go.Scatter(x=all_fpr, y=mean_tpr, mode="lines", name=f"{name} (macro AUC={auc(all_fpr,mean_tpr):.3f})"))
            except Exception:
                pass

            # Confusion matrices
            cm_train = confusion_matrix(y_train, y_pred_tr, labels=class_labels)
            cm_test  = confusion_matrix(y_test,  y_pred_te, labels=class_labels)

            # Save model
            st.session_state.trained_models[name] = pipe

            results.append({
                "Algorithm": name,
                "CV(5)-Acc (tiny)": cv_acc,
                "Train Acc": tr_acc,
                "Test Acc": te_acc,
                "Precision (weighted)": precision,
                "Recall (weighted)": recall,
                "F1 (weighted)": f1,
                "AUC": auc_value,
                "CM Train": cm_train,
                "CM Test": cm_test,
                "Labels": class_labels
            })

        # Metrics table
        res_df = (pd.DataFrame([{k:v for k,v in r.items() if not isinstance(v, (np.ndarray, list))} for r in results])
                  .set_index("Algorithm")
                  .round(4))
        st.dataframe(res_df, use_container_width=True)

        # Confusion matrices (plotly heatmaps)
        for r in results:
            lbls = [str(x) for x in r["Labels"]]
            for split, cm in [("Train", r["CM Train"]), ("Test", r["CM Test"])]:
                fig_cm = go.Figure(data=go.Heatmap(
                    z=cm, x=lbls, y=lbls, hoverongaps=False, coloraxis="coloraxis"
                ))
                fig_cm.update_layout(
                    title=f"{r['Algorithm']} - {split} Confusion Matrix",
                    xaxis_title="Predicted", yaxis_title="Actual",
                    coloraxis={"colorscale":"Blues"}
                )
                st.plotly_chart(fig_cm, use_container_width=True)

        # ROC
        roc_fig.add_trace(go.Scatter(x=[0,1], y=[0,1], mode="lines", name="Baseline", line=dict(dash="dash")))
        roc_fig.update_layout(title="ROC Curve – All Models", xaxis_title="FPR", yaxis_title="TPR")
        st.plotly_chart(roc_fig, use_container_width=True)

# ------------------------------
# Tab 4: Batch Predict & Download
# ------------------------------
with tab4:
    st.subheader("Upload new data and predict Policy Status")
    st.write("Uses the **best available trained model** from the Model Lab. If none trained this session, click the button below to train a default Random Forest first.")

    ensure_session_models()

    if len(st.session_state.trained_models) == 0:
        if st.button("Train a quick Random Forest now"):
            # Default train on current df
            X = df.drop(columns=[target_col])
            y = df[target_col].astype(str)
            num_cols, cat_cols_mod = get_feature_splits(df, target_col)
            preprocess = build_preprocess(num_cols, cat_cols_mod)
            rf = RandomForestClassifier(n_estimators=200, random_state=42)
            pipe = Pipeline([("preprocess", preprocess), ("model", rf)])
            pipe.fit(X, y)
            st.session_state.trained_models["Random Forest"] = pipe
            st.session_state.class_labels = np.unique(y).tolist()
            st.session_state.target_col = target_col
            st.success("Quick Random Forest trained!")

    # Pick a model to use
    model_names = list(st.session_state.trained_models.keys())
    if model_names:
        model_choice = st.selectbox("Choose trained model for prediction", model_names, index=0)
        model = st.session_state.trained_models[model_choice]
    else:
        st.info("No trained models available yet.")
        model = None

    new_upload = st.file_uploader("Upload new dataset (CSV) to score", type=["csv"], key="newscore")
    if new_upload and model:
        new_df = pd.read_csv(new_upload)
        # Keep only features present in training pipeline where possible
        st.write(f"Uploaded rows: {len(new_df)}")

        # Predict
        preds = model.predict(new_df)
        # If proba available, add max prob
        try:
            proba = model.predict_proba(new_df)
            if proba.ndim == 2:
                max_proba = proba.max(axis=1)
                new_df["PRED_PROBA_MAX"] = max_proba
        except Exception:
            pass

        new_df["PRED_POLICY_STATUS"] = preds

        st.dataframe(new_df.head(100), use_container_width=True)

        # Download button
        csv = new_df.to_csv(index=False).encode("utf-8")
        st.download_button("⬇️ Download Scored File", data=csv, file_name="scored_predictions.csv", mime="text/csv")
    elif new_upload and not model:
        st.warning("Please train a model first (either in Model Lab, or via the quick RF button).")
